const {
  Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder,
  ButtonBuilder, ButtonStyle,
} = require('discord.js');
const {
  joinVoiceChannel, createAudioPlayer, createAudioResource,
  AudioPlayerStatus, StreamType, VoiceConnectionStatus,
  entersState, getVoiceConnection,
} = require('@discordjs/voice');
const { spawn, execFile } = require('child_process');

const TOKEN = process.env.TOKEN || 'حط_التوكن_هنا';
const PREFIX = '!';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// حالة كل سيرفر
const states = new Map();
function getState(guildId) {
  if (!states.has(guildId)) {
    const player = createAudioPlayer();
    const st = { player, queue: [], index: -1, proc: null, msg: null, textChannel: null };
    player.on(AudioPlayerStatus.Idle, () => {
      // انتهت الاغنية طبيعيا -> التالية
      if (st.index + 1 < st.queue.length) playAt(guildId, st.index + 1);
    });
    player.on('error', (e) => console.error('Player error:', e.message));
    states.set(guildId, st);
  }
  return states.get(guildId);
}

function getTitle(url) {
  return new Promise((resolve) => {
    execFile('yt-dlp', ['--no-playlist', '--print', 'title', url], { timeout: 20000 },
      (err, out) => resolve(err || !out.trim() ? url : out.trim().split('\n')[0]));
  });
}

function killProc(st) {
  if (st.proc) { try { st.proc.kill('SIGKILL'); } catch {} st.proc = null; }
}

function controls(st) {
  const paused = st.player.state.status === AudioPlayerStatus.Paused;
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('prev').setEmoji('⏮️').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('pause').setEmoji(paused ? '▶️' : '⏸️').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('next').setEmoji('⏭️').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('list').setEmoji('📜').setLabel('القائمة').setStyle(ButtonStyle.Success),
  );
}

function nowEmbed(st) {
  const t = st.queue[st.index];
  return new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle('🎵 يشتغل الحين')
    .setDescription(`**${t.title}**\n${t.url}`)
    .setFooter({ text: `${st.index + 1} / ${st.queue.length}` });
}

async function playAt(guildId, i) {
  const st = getState(guildId);
  const track = st.queue[i];
  if (!track) return;
  st.index = i;
  killProc(st);

  const proc = spawn('yt-dlp', [
    '-q', '--no-warnings', '--no-playlist',
    '-f', 'bestaudio/best', '-o', '-', track.url,
  ], { stdio: ['ignore', 'pipe', 'ignore'] });
  proc.on('error', (e) => console.error('yt-dlp error:', e.message));
  st.proc = proc;

  const resource = createAudioResource(proc.stdout, { inputType: StreamType.Arbitrary });
  st.player.play(resource);

  // قائمة التحكم
  if (st.textChannel) {
    if (st.msg) st.msg.edit({ components: [] }).catch(() => {});
    st.msg = await st.textChannel
      .send({ embeds: [nowEmbed(st)], components: [controls(st)] })
      .catch(() => null);
  }
}

client.once('clientReady', () => console.log(`✅ شغال: ${client.user.tag}`));

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild || !message.content.startsWith(PREFIX)) return;
  const [cmd, ...args] = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const guildId = message.guild.id;

  // !start <id الروم>
  if (cmd === 'start') {
    const id = (args[0] || '').replace(/\D/g, '');
    const ch = id && (await message.guild.channels.fetch(id).catch(() => null));
    if (!ch || !ch.isVoiceBased()) return message.reply('❌ اكتب ايدي روم صوتي صحيح: `!start ID`');
    try {
      const conn = joinVoiceChannel({
        channelId: ch.id,
        guildId,
        adapterCreator: message.guild.voiceAdapterCreator,
        selfDeaf: true,
      });
      await entersState(conn, VoiceConnectionStatus.Ready, 20000);
      const st = getState(guildId);
      conn.subscribe(st.player);
      st.textChannel = message.channel;
      // اعادة الاتصال تلقائيا لو انقطع
      conn.on(VoiceConnectionStatus.Disconnected, async () => {
        try {
          await Promise.race([
            entersState(conn, VoiceConnectionStatus.Signalling, 5000),
            entersState(conn, VoiceConnectionStatus.Connecting, 5000),
          ]);
        } catch { conn.destroy(); }
      });
      message.reply(`✅ دخلت **${ch.name}**`);
    } catch (e) {
      console.error(e);
      message.reply('❌ ما قدرت ادخل الروم (تأكد من الصلاحيات)');
    }
  }

  // !song <رابط>
  else if (cmd === 'song') {
    const url = args[0];
    if (!url) return message.reply('❌ اكتب رابط: `!song الرابط`');
    const conn = getVoiceConnection(guildId);
    if (!conn) return message.reply('❌ اكتب `!start ID` اول');
    const st = getState(guildId);
    st.textChannel = message.channel;
    const wait = await message.reply('⏳ جاري التحميل...');
    const title = await getTitle(url);
    st.queue.push({ url, title });
    wait.edit(`➕ انضافت: **${title}**`).catch(() => {});
    const idle = st.player.state.status === AudioPlayerStatus.Idle;
    if (idle && st.index === st.queue.length - 2) playAt(guildId, st.queue.length - 1);
    else if (idle) playAt(guildId, st.queue.length - 1);
  }

  // !stop
  else if (cmd === 'stop') {
    const st = getState(guildId);
    killProc(st);
    st.player.stop(true);
    st.queue = [];
    st.index = -1;
    if (st.msg) st.msg.edit({ components: [] }).catch(() => {});
    st.msg = null;
    const conn = getVoiceConnection(guildId);
    if (conn) conn.destroy();
    message.reply('👋 طلعت من الروم');
  }
});

// ازرار التحكم
client.on('interactionCreate', async (i) => {
  if (!i.isButton() || !i.guild) return;
  const st = getState(i.guild.id);
  const gid = i.guild.id;

  if (i.customId === 'list') {
    const text = st.queue.length
      ? st.queue.map((t, n) => `${n === st.index ? '▶️' : `${n + 1}.`} ${t.title}`).join('\n').slice(0, 1900)
      : 'القائمة فاضية';
    return i.reply({ content: `📜 **قائمة التشغيل**\n${text}`, ephemeral: true });
  }

  if (i.customId === 'pause') {
    if (st.player.state.status === AudioPlayerStatus.Paused) st.player.unpause();
    else st.player.pause();
    return i.update({ components: [controls(st)] });
  }

  if (i.customId === 'next') {
    if (st.index + 1 >= st.queue.length) return i.reply({ content: 'ما فيه اغنية بعدها', ephemeral: true });
    await i.deferUpdate();
    return playAt(gid, st.index + 1);
  }

  if (i.customId === 'prev') {
    if (st.index <= 0) return i.reply({ content: 'هذي اول اغنية', ephemeral: true });
    await i.deferUpdate();
    return playAt(gid, st.index - 1);
  }
});

process.on('unhandledRejection', (e) => console.error('Unhandled:', e));
client.login(TOKEN);
